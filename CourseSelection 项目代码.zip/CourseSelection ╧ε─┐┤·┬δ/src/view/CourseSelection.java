package view;

public class CourseSelection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************************");
		System.out.println("----------------------��ӭ����ѡ��ϵͳ��--------------------");
		MainUI.show();
	}

}
