package entity;

public interface IEntity {
	

}
